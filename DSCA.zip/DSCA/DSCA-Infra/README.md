# kinja-infrastructure

__This repository holds templates to bring up kinja infrastructure using AWS Cloudformation.__

| Environment |     Status    |
|-------------|:-------------:|
| staging     | [![CircleCI](https://circleci.com/gh/gawkermedia/kinja-infrastructure/tree/staging.svg?style=svg&circle-token=f374177d1735d69064464d0b643b6a1a041ca77f)](https://circleci.com/gh/gawkermedia/kinja-infrastructure/tree/staging) |
| production  | [![CircleCI](https://circleci.com/gh/gawkermedia/kinja-infrastructure/tree/production.svg?style=svg&circle-token=f374177d1735d69064464d0b643b6a1a041ca77f)](https://circleci.com/gh/gawkermedia/kinja-infrastructure/tree/production) |

## repository layout

* `buildspec.yml` - [AWS CodeBuild](http://docs.aws.amazon.com/codebuild/latest/userguide/build-spec-ref.html) configuration file
* `circle.yml` - [CircleIO](https://circleci.com/gh/gawkermedia/kinja-infrastructure) configuration file
* `cloudformation` - [AWS Cloudformation](https://aws.amazon.com/cloudformation/) templates
* `configs` - environment configuration files
* `kubernetes` - [Kubernetes](https://kubernetes.io/) configuration files
* `lambdas` - [AWS Lambda](https://aws.amazon.com/lambda/) sources
* `manage.py` - management script to validate, bundle
* `requirements.txt` - pip reqs for the management script

## getting started...

* `pip install -r requirements.txt`
* bundle creation: `./manage.py create_bundle`
* validation: `./manage.py validate`

