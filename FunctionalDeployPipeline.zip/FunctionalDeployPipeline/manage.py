#! /usr/bin/env python

import click
import boto3
from botocore.config import Config
import os
import json
import py_compile
import shutil
import pip
import hashlib

# ENVIRONMENTAL VARIABLES

S3_BUCKET="api-infra-cloudformation-validator"
CLOUDFORMATION_LOCAL_VALIDATE_LIMIT=51200
DEFAULT_BUNDLE_DIRECTORY="build"
CONFIGURATION_DIRECTORY="configs"
CLOUDFORMATION_DIRECTORY='cloudformation'
TMP_DIR=".tmp"

# UTILS

def _walklevel(some_dir, level=1):
    some_dir = some_dir.rstrip(os.path.sep)
    assert os.path.isdir(some_dir)
    num_sep = some_dir.count(os.path.sep)
    for root, dirs, files in os.walk(some_dir):
        yield root, dirs, files
        num_sep_this = root.count(os.path.sep)
        if num_sep + level <= num_sep_this:
            del dirs[:]

def _list_files(directory, extension):
    files = []
    for filename in os.listdir(directory):
        if filename.endswith(extension):
            template = os.path.join(directory, filename)
            files.append(template)
    return files

def _list_directories(directory):
    return [dir[0] for dir in _walklevel(directory) if dir[0] != directory]

def _run_for_each(seq, method):
    ret = []
    for obj in seq:
         ret.append(method(obj))
    return ret

def _install_pip_requirements(path, target):
    pip.main(['install', '-r', path, '-t', target])

def _zip(source, destination):
    shutil.make_archive(
      base_name=destination,
      format='zip',
      root_dir=source
    )

def _get_file_size(path):
    statinfo = os.stat(path)
    return statinfo.st_size

def _upload_to_s3(path, bucket, key):
    s3 = boto3.client('s3')
    with open(path, 'rb') as data:
        s3.upload_fileobj(data, bucket, key)

def _render_configuration(source, destination, fields):
    with open(source) as data_file:
        data = json.load(data_file)
    location=os.path.join(destination, os.path.basename(source))
    for k,v in list(fields.items()):
        data['Parameters'][k] = v
    with open(location, 'w') as outfile:
            json.dump(data, outfile)

# VALIDATOR PRIMITIVES

def validate_local_cloudformation_template(path):
    click.echo("Validating (local)... [%s]" % path)
    client = boto3.client('cloudformation', config=Config(retries={'max_attempts': 10}))
    response=""
    try:
        with open(path, 'r') as template_file:
                    body=template_file.read()
                    response = client.validate_template(
                        TemplateBody=body
                    )
    except:
        click.echo("...FAIL...")
        raise
    click.echo("...PASS...")
    return response

def validate_remote_cloudformation_template(path):
    click.echo("Validating (remote)... [%s]" % path)

    key=hashlib.md5(path).hexdigest()
    _upload_to_s3(path, S3_BUCKET, key)

    client = boto3.client('cloudformation', config=Config(retries={'max_attempts': 10}))
    try:
       location = 'https://s3.amazonaws.com/' + S3_BUCKET + '/' + key
       client.validate_template(TemplateURL=location)
    except:
        click.echo("...FAIL...")
        raise
    click.echo("...PASS...")

def validate_cloudformation_template_file(path):
    if _get_file_size(path) <= CLOUDFORMATION_LOCAL_VALIDATE_LIMIT:
        return validate_local_cloudformation_template(path)
    else:
        return validate_remote_cloudformation_template(path)

def validate_python_file(path):
    click.echo("Compiling python file... [%s]" % path)
    py_compile.compile(path, doraise=True)
    os.remove(path+'c') # removing pyc files

def validate_configuration_file(path):
    click.echo("Validating... [%s]" % path)
    with open(path) as config_file:
        json.load(config_file)
    click.echo("...PASS...")

# ENVIRONMENT VALIDATORS

def validate_cloudformation_templates(filename=None):
    click.echo("Validating cloudformation templates...")
    templates = _list_files(CLOUDFORMATION_DIRECTORY, ".yaml") if not filename else [filename]
    _run_for_each(templates, validate_cloudformation_template_file)

def validate_configuration_files(filename=None):
    click.echo("Validating configuration files...")
    configurations = _list_files(CONFIGURATION_DIRECTORY, ".json") if not filename else [filename]
    _run_for_each(configurations, validate_configuration_file)

# BUNDLE GENERATORS

def create_deployment_bundle(directory, validate, initiator, id):
    click.echo("Creating deployment bundle...")

    if validate:
        validate_cloudformation_templates()
        validate_configuration_files()

    if os.path.exists(directory):
      shutil.rmtree(directory)

    if os.path.exists(TMP_DIR):
      shutil.rmtree(TMP_DIR)

    os.mkdir(TMP_DIR)
    os.mkdir(directory)

    # CLOUDFORMATION
    shutil.copytree(CLOUDFORMATION_DIRECTORY, os.path.join(directory, CLOUDFORMATION_DIRECTORY))

    # CONFIGURATION
    os.mkdir(os.path.join(directory, CONFIGURATION_DIRECTORY))
    GENERATED_FIELDS = {
        'StackConfigurationBucket': initiator,
        'StackBuildId': id
    }

    configurations = _list_files(CONFIGURATION_DIRECTORY, ".json")
    for config in configurations:
        _render_configuration(config, os.path.join(directory, CONFIGURATION_DIRECTORY), GENERATED_FIELDS)

    shutil.rmtree(TMP_DIR)

    click.echo("Bundle has been created...")


# COMMANDLINE DEFINITIONS

@click.group()
def cli():
    pass

@cli.command(help='validate cloudformation templates or a specific template file')
@click.option('--filename', default=None, help='path to the cloudformation template to be validated')
def validate_cloudformation(filename):
    validate_cloudformation_templates(filename)

@cli.command(help='validate cloudformation configuration file')
@click.option('--filename', default=None, help='path to the configuration file to be validated')
def validate_configuration(filename):
    validate_configuration_files(filename)

@cli.command(help='run validation tests')
def validate():
    validate_cloudformation_templates()
    validate_configuration_files()

@cli.command(help='create deployment bundle')
@click.option('--directory', default=DEFAULT_BUNDLE_DIRECTORY, help='deployment bundle directory location')
@click.option('--initiator', default="USER", help='name of the deployment initiator')
@click.option('--id', default="USER", help='name of the deployment id')
@click.option('--validate/--no-validate', default=True, help='run validation before creating the bundle')
def create_bundle(directory, validate, initiator, id):
    create_deployment_bundle(directory, validate, initiator, id)

if __name__ == '__main__':
    try:
        cli()
    except Exception as e:
        click.echo(str(e))
        exit(-1)
