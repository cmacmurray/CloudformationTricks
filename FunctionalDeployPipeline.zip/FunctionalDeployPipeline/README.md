# How to use this setup

## Prerequisites
We assume that you already have configured AWS profile with a name `univision` by running the following command:
```
aws configure --profile univision
```

## Repository Layout
* [pipeline.yaml](): This is the only thing to be submitted to CloudFormation. It does the rest.
	* CodePipeline that deploys the nested stacks. Requires a GitHub URL, token, and branch name.
	* The appropriate file from [configs/]() is chosen based on the `Environment` parameter

* [cloudformation/main.yaml](): The parent stack. All other stacks are deployed as nested stacks from here.
* [cloudformation/network.yaml](): 
	* VPC
	* Security groups
	* NAT gateways
	* Anything else network related.

* [cloudformation/rds.yaml](): 
	* RDS instances

	Uses parameter mappings for application specific configuration.

* [cloudformation/ec2-roles-and-profiles.yaml]():  
	* Instance roles
	* Service roles

* [cloudformation/ecs-clusters.yaml]():
	* Empty ECS cluster
	
	Uses parameter mappings for application specific configuration.

* [cloudformation/kinesis.yaml]():
	* Kinesis streams for metadata

  Uses parameter mappings for application specific configuration.
	
* [cloudformation/iam-system-roles.yaml]():
	* Application specific IAM roles

* [cloudformation/ECR.yaml]():
	* Empty ECR repo

  Uses parameter mappings for application specific configuration.

* [cloudformation/iam-user-data.yaml]():
	* IAM users for deployment accounts
	
* [cloudformation/app0001.yaml]():
	* ECS service
	* Task definitions
	* EC2 launch configurations
	* ALB
	* Target groups
	* Auto Scaling rules
	* CloudWatch alarms

	Uses parameter mappings for application specific configuration.
	
 * [cloudformation/route53.yaml]():
	 * Public Zones
	 * Private Zones

* [cloudformation/waf.yaml]():
	* Web Application Firewall for Deportes API

* [cloudformation/codedeploy.yaml]():
	* CodePipline S3 bucket
	* CodePipeline IAM roles
	* CodePipeline KMS key

* [cloudformation/api-deportes-0001.yaml]():
	* Deportes API Gateway
	* Deportes Custom Domains

* [cloudformation/api-k8s-meta-data-profile-0001.yaml]():
	* Profile and metadata API Gateway
	* Profile and metadata Custom Domains

	Uses parameter mappings for application specific configuration.

* [cloudformation/jenkins.yaml]():
	* The Jenkins server built from a previous AMI snapshot

## Validating Changes
This assumes you have an AWS profile named `univision` set up in `.aws/credentials`
```
sudo pip install virtualenvwrapper --ignore-installed six
```
Add the following lines into `~/.bashrc` (Location will differ if on Linux)
```
export VIRTUALENVWRAPPER_PYTHON=/usr/local/bin/python
export VIRTUALENVWRAPPER_VIRTUALENV=/usr/local/bin/virtualenv
source /usr/local/bin/virtualenvwrapper.sh
```

Go to this repo directory and run the following:
```
mkvirtualenv test
pip install -r requirements.txt
pip freeze
AWS_PROFILE=univision ./manage.py validate
```

## Deploying This Stack
Run [pipeline.yaml]() in CloudFormation. Set the parameters:
* Environment
* CodePipelineName
* CodePipelineBranch
* GithubToken
* StackName - **This must be different from the main stack name! It will break badly if it is not.**

## Deploying Containers
Jenkins is and the devs are responsible for container deployment. There are, however, idiosyncrasies that if not observed, will break things. This isn't the right way to do it and we'll be fixing it later.

### Before Deploying to Cloudformation

1. Open the app stack (currently [app0001.yaml](cloudformation/app0001.yaml))
2. Go the the mapping `AppParams`
3. For the environment you are working on, make sure the counts look like 
```
"AppInstanceMinCount": "4"
"AppInstanceMaxCount": "10"
"AppTaskMinCount": "0"
"AppTaskMaxCount": "12"
```
4. **IMPORTANT** `AppTaskMinCount` must be `0`! This is because the ECR repo is initially empty and won't have images to deploy to it. It will cause CloudFormation to get stuck otherwise.

### After Deploying to CloudFormation

1. In your deployment tool of choice (Jenkins, CodePipeline), via the AWS API deploy the initial image, create new task definitions, and update the service. Do **NOT** set `desired-count` from here.
2. After the initial container deployment, log into the AWS console and manually update the ECS service with the following settings:
	* Minimum number of tasks: `4`
	* Desired number of tasks: `4`
3. After that, autoscaling will handle the desired count

### Problems With This
Since new task definitions are created with CloudFormation, they are out of band changes. This means after deployment `AppTaskMinCount`, `AppTaskMaxCount`, and `AppTaskDefinition` in app.yaml can't be edited post-deployment. If they are, CloudFormation will deploy an older version of the task definition and CloudFormation may get confused.

### How to Fix The Problems With This
The task creation and service updates need to be done via CloudFormation too. There are two methods with which this could be accomplished.

#### Method 1

 1. Have the initial CloudFormation deployment create an empty cluster
 2. Have the CI process deploy separate CloudFormation templates for task and service creation

#### Method 2

1. Keep all the CloudFormation templates all together (clusters, services, and tasks) and have the CI process redeploy it while passing in an incremented task version number.

## Notes
* This repo has the same layout as [gmgawsprod](https://github.com/gawkermedia/gmgawsprod) repo
* When specifying CloudFormation file to use provide a path to `pipeline.cf` file
* CodeBuild service uses `buildspec.yaml`
# How to use this setup

## Prerequisites
We assume that you already have configured AWS profile with a name `univision` by running the following command:
```
aws configure --profile univision
```

## Repository Layout
* [pipeline.yaml](): This is the one of two stacks to be submitted to CloudFormation. It does the rest.
	* CodePipeline that deploys the nested stacks. Requires a GitHub URL, token, and branch name.
	* The appropriate file from [configs/]() is chosen based on the `Environment` parameter

* [iam-individuals.yaml](): Manages individual IAM users. It is a non-nested stack to be submitted manually. It was done like this so there would not be IAM user name conflicts when deploying the same stack to another region.

* [cloudformation/main.yaml](): The parent stack. All other stacks are deployed as nested stacks from here.
* [cloudformation/network.yaml](): 
	* VPC
	* Security groups
	* NAT gateways
	* Anything else network related.

* [cloudformation/rds.yaml](): 
	* RDS instances

	Uses parameter mappings for application specific configuration.

* [cloudformation/ec2-roles-and-profiles.yaml]():  
	* Instance roles
	* Service roles

* [cloudformation/ecs-clusters.yaml]():
	* Empty ECS cluster
	
	Uses parameter mappings for application specific configuration.
	
* [cloudformation/kinesis.yaml]():
	* Kinesis streams for metadata

	Uses parameter mappings for application specific configuration.
		
* [cloudformation/iam-system-roles.yaml]():
	* Application specific IAM roles

* [cloudformation/ECR.yaml():
	* Empty ECR repo

	Uses parameter mappings for application specific configuration.
	
* [cloudformation/iam-user-data.yaml]():
	* IAM users for deployment accounts
	
* [cloudformation/app0001.yaml]():
	* ECS service
	* Task definitions
	* EC2 launch configurations
	* ALB
	* Target groups
	* Autoscaling rules
	* CloudWatch alarms

	Uses parameter mappings for application specific configuration.
		
 * [cloudformation/route53.yaml]():
	 * Public Zones
	 * Private Zones

* [cloudformation/waf.yaml]():
	* Web Application Firewall for Deports API

* [cloudformation/codedeploy.yaml]():
	* CodePipline S3 bucket
	* CodePipeline IAM roles
	* CodePipeline KMS key

* [cloudformation/api-deportes-0001.yaml]():
	* Deportes API Gateway
	* Deportes Custom Domains

	Uses parameter mappings for application specific configuration.
	
* [cloudformation/jenkins.yaml]():
	* The Jenkins server built from a previous AMI snapshot

## Validating Changes
This assumes you have an AWS profile named `univision` set up in `.aws/credentials`
```
sudo pip install virtualenvwrapper --ignore-installed six
```
Add the following lines into `~/.bashrc` (Location will differ if on Linux)
```
export VIRTUALENVWRAPPER_PYTHON=/usr/local/bin/python
export VIRTUALENVWRAPPER_VIRTUALENV=/usr/local/bin/virtualenv
source /usr/local/bin/virtualenvwrapper.sh
```

Go to this repo directory and run the following:
```
mkvirtualenv test
pip install -r requirements.txt
pip freeze
AWS_PROFILE=univision ./manage.py validate
```

## Deploying This Stack
Run [pipeline.yaml]() in CloudFormation. Set the parameters:
* Environment
* CodePipelineName
* CodePipelineBranch
* GithubToken
* StackName - **This must be different from the main stack name! It will break badly if it is not.**

## Deploying Containers
Jenkins is and the devs are responsible for container deployment. There are, however, idiosyncrasies that if not observed, will break things. This isn't the right way to do it and we'll be fixing it later.

### Before Deploying to Cloudformation

1. Open the app stack (currently [app0001.yaml](cloudformation/app0001.yaml))
2. Go the the mapping `AppParams`
3. For the environment you are working on, make sure the counts look like 
```
"AppInstanceMinCount": "4"
"AppInstanceMaxCount": "10"
"AppTaskMinCount": "0"
"AppTaskMaxCount": "12"
```
4. **IMPORTANT** `AppTaskMinCount` must be `0`! This is because the ECR repo is initially empty and won't have images to deploy to it. It will cause CloudFormation to get stuck otherwise.
5. Manually create a hosted zone for the public domain you intend to use and put that into the config json
6. Manually create an ACM certificate and put its ARN into the config json

### After Deploying to CloudFormation

1. In your deployment tool of choice (Jenkins, CodePipeline), via the AWS API deploy the initial image, create new task definitions, and update the service. Do **NOT** set `desired-count` from here.
2. After the initial container deployment, log into the AWS console and manually update the ECS service with the following settings:
	* Minimum number of tasks: `4`
	* Desired number of tasks: `4`
3. After that, autoscaling will handle the desired count

### Problems With This
Since new task definitions are created with CloudFormation, they are out of band changes. This means after deployment `AppTaskMinCount`, `AppTaskMaxCount`, and `AppTaskDefinition` in app.yaml can't be edited post-deployment. If they are, CloudFormation will deploy an older version of the task definition and CloudFormation may get confused.

### How to Fix The Problems With This
The task creation and service updates need to be done via CloudFormation too. There are two methods with which this could be accomplished.

#### Method 1

 1. Have the initial CloudFormation deployment create an empty cluster
 2. Have the CI process deploy separate CloudFormation templates for task and service creation

#### Method 2

1. Keep all the CloudFormation templates all together (clusters, services, and tasks) and have the CI process redeploy it while passing in an incremented task version number.

## Notes
* This repo has the same layout as [gmgawsprod](https://github.com/gawkermedia/gmgawsprod) repo
* When specifying CloudFormation file to use provide a path to `pipeline.cf` file
* CodeBuild service uses `buildspec.yaml`
