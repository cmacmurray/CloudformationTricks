# TODO
- Change configuration references in main.yaml
- Define environment variable for lambda to what Slack channel to send messages to
- Create a CircleCI account (Permissions -> AWS Permissions)
- Create github bot users and create Github Token for that and ass it to CodePipeline
